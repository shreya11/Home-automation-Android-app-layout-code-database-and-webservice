-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2015 at 10:31 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `enerleaf_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `Admin_ID` varchar(5) NOT NULL,
  `Reference_ID` varchar(10) NOT NULL,
  `Switch_BoardID` bigint(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Admin_ID`, `Reference_ID`, `Switch_BoardID`) VALUES
('A2', '2', 4126),
('A3', '3', 6128),
('A4', '4', 6128);

-- --------------------------------------------------------

--
-- Table structure for table `bill_payment`
--

CREATE TABLE IF NOT EXISTS `bill_payment` (
  `idBill_Payment` double NOT NULL,
  `Date` date NOT NULL,
  `Requested_Balance` float NOT NULL,
  `Balance_Used(Light_Bill)` float NOT NULL,
  `User_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bill_payment`
--

INSERT INTO `bill_payment` (`idBill_Payment`, `Date`, `Requested_Balance`, `Balance_Used(Light_Bill)`, `User_ID`) VALUES
(222, '0000-00-00', 5000, 2000, 1),
(223, '0000-00-00', 7000, 8000, 2),
(224, '0000-00-00', 2000, 1500, 3);

-- --------------------------------------------------------

--
-- Table structure for table `consumption`
--

CREATE TABLE IF NOT EXISTS `consumption` (
  `Consumption_A_Day` float NOT NULL,
  `Switch_Board_ID` bigint(8) NOT NULL,
  `Consumption_Date` date NOT NULL,
  `switch_ID` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `consumption`
--

INSERT INTO `consumption` (`Consumption_A_Day`, `Switch_Board_ID`, `Consumption_Date`, `switch_ID`) VALUES
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(54, 7127, '2015-06-05', 3),
(65, 6125, '2015-06-30', 4);

-- --------------------------------------------------------

--
-- Table structure for table `device_information`
--

CREATE TABLE IF NOT EXISTS `device_information` (
  `idDevice` int(11) NOT NULL,
  `Device_Name` varchar(15) NOT NULL,
  `Device_Price` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `device_information`
--

INSERT INTO `device_information` (`idDevice`, `Device_Name`, `Device_Price`) VALUES
(1, 'fan', 0),
(2, 'cooler', 0),
(3, 'ac', 0),
(4, 'tv', 0),
(5, 'x', 0),
(6, 'y', 0),
(7, 'z', 0),
(8, 'w', 0);

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

CREATE TABLE IF NOT EXISTS `home` (
  `idHome` varchar(10) NOT NULL,
  `High_Alert` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`idHome`, `High_Alert`) VALUES
('h1', 0),
('h2', 0),
('h3', 0),
('h4', 0),
('h6', 0);

-- --------------------------------------------------------

--
-- Table structure for table `master_user`
--

CREATE TABLE IF NOT EXISTS `master_user` (
  `idUser_Information` int(10) NOT NULL,
  `User_Name` varchar(45) NOT NULL,
  `User_Address` varchar(100) NOT NULL,
  `Contact_Number` varchar(13) NOT NULL,
  `No_Of_SwitchBoards` int(10) NOT NULL,
  `Authentication_ID` varchar(100) NOT NULL,
  `Password` varchar(22) NOT NULL,
  `Home__ID` varchar(10) DEFAULT NULL,
  `App_IP` varchar(45) DEFAULT NULL,
  `APP_ID` varchar(25) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `master_user`
--

INSERT INTO `master_user` (`idUser_Information`, `User_Name`, `User_Address`, `Contact_Number`, `No_Of_SwitchBoards`, `Authentication_ID`, `Password`, `Home__ID`, `App_IP`, `APP_ID`) VALUES
(1, 'sddff', 'bjhgvvbb', '898055555', 2, 'aaaa@gmail.com', 'gopal', 'h1', '7678.876.56.9878', NULL),
(2, 'shreya', 'bjhgvvbb', '8980758885', 38, 'shreya@gmail.com', 'sh', 'h2', '554.87.56.454', NULL),
(3, 'sddff', 'bjhgvvbb', '11111111', 2, 'shreyagokani@gmail.com', 'shreya', 'h3', '545.76.45.76', NULL),
(4, 'goku', '', '8980758885', 0, 'gggg@gmail.com', 'gggg', NULL, NULL, NULL),
(9, 'hhhh', '', '99999', 0, 'fggff', 'aaaa', NULL, NULL, NULL),
(10, 'hhhh', '', '999999', 0, 'hhhh@gmail.com', 'hhhh', NULL, NULL, NULL),
(13, 'hghg', '', '888888', 0, 'hghg@gmail.com', 'jjjj', NULL, NULL, '7c:1d:d9:47:a1:bf'),
(14, 'cccc', '', '898989', 0, 'cccc@gmail.com', 'ccc', NULL, NULL, '00:F4:6F:C2:2F:83'),
(15, 'dddd', '', '9999999366', 0, 'dddd@gmail.com', 'dddd', NULL, NULL, '00:F4:6F:C2:2F:83'),
(16, 'eeee', '', '1111111', 0, 'd@gmail.com', 'eee', NULL, NULL, '00:F4:6F:C2:2F:83'),
(17, 'fff', '', '22222', 0, 'fff@gmail.com', 'fff', NULL, NULL, '00:F4:6F:C2:2F:83'),
(18, 'ssss', '', '223333', 0, 'sss@gmail.com', 'sss', NULL, NULL, '00:F4:6F:C2:2F:83'),
(19, 'rrrr', '', '00000000', 0, 'rrrr@gmail.com', 'rrr', NULL, NULL, '00:F4:6F:C2:2F:83'),
(20, 'qqq', '', '12121', 0, 'qetc', 'dd', NULL, NULL, '00:F4:6F:C2:2F:83'),
(21, 'ww', '', '963655', 0, 'wryh', 'ww', NULL, NULL, '00:F4:6F:C2:2F:83'),
(22, 'kkk', '', '6399', 0, 'lbb', 'kk', NULL, NULL, '00:F4:6F:C2:2F:83'),
(23, 'll', '', '23955', 0, 'lll', 'll', NULL, NULL, '00:F4:6F:C2:2F:83'),
(24, 'ghgc', '', '9658', 0, 'jjcc', 'cc', NULL, NULL, '00:F4:6F:C2:2F:83'),
(25, 'hvc', '', '8980758885', 0, 'bdf', 'aaa', NULL, NULL, '00:F4:6F:C2:2F:83');

-- --------------------------------------------------------

--
-- Table structure for table `reference_switchboards`
--

CREATE TABLE IF NOT EXISTS `reference_switchboards` (
  `Reference__UserID` varchar(10) NOT NULL,
  `SwitchBoard_ID` bigint(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reference_switchboards`
--

INSERT INTO `reference_switchboards` (`Reference__UserID`, `SwitchBoard_ID`) VALUES
('2', 6128),
('2', 4126),
('1', 7124),
('3', 7124),
('3', 6128),
('4', 6125),
('4', 6128),
('3', 7124),
('1', 7129),
('5', 6128),
('5', 4123);

-- --------------------------------------------------------

--
-- Table structure for table `reference_user`
--

CREATE TABLE IF NOT EXISTS `reference_user` (
  `idReference_User` varchar(10) NOT NULL,
  `Reference_Name` varchar(45) DEFAULT NULL,
  `Reference_Address` varchar(100) DEFAULT NULL,
  `Reference_Contact_No` varchar(13) DEFAULT NULL,
  `Reference_Authentication_ID` varchar(100) DEFAULT NULL,
  `Reference_Password` varchar(22) DEFAULT NULL,
  `App_ID_Mac` varchar(25) DEFAULT NULL,
  `IP_ADD` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reference_user`
--

INSERT INTO `reference_user` (`idReference_User`, `Reference_Name`, `Reference_Address`, `Reference_Contact_No`, `Reference_Authentication_ID`, `Reference_Password`, `App_ID_Mac`, `IP_ADD`) VALUES
('1', 'Suthar Bhai', '16/1,Devendra Society, Naranpura, Ahmedabad', '9876865565', 'sutharbhai1234@gmail.com', 'suthar@1234', '19.89.07.98', '187.976.45.654'),
('112', '99999999', NULL, 'dfff', 'dfff@Gmail.com', NULL, NULL, NULL),
('2', 'Bhavna ben', '42, saryu flats, Mithakhali 6 roads, Ahmedabad', '8984533445', 'bhavnatutu222@gmail.com', 'bhtutu@1030e', '65.876.00.00', '6867.08.45.3345'),
('3', 'Kamlesh', '554,ghffddsskfffhddhddhfhhfhthgnfdfkfhj', '4856844943', 'dhghjfkdjngfgjkf@gmail.com', 'gngfjkn43585', '8767.434.34.65', '234.544.46.09'),
('4', 'mahin', '56egghhjhgmnjghfddffdgjjmnmngffddsdgfghgfjhjkkjkjhggfdfddffghgjgfgrretrhjbvccxadssaertyuhjhjbvvbfdf', '8686767567', 'gvfdhgfmnjv3543@gmail.com', 'ghujhng56', '5687.99.88.66', '556.088.576.565'),
('5', 'Shreya', 'ghhgfdfdfffffffffffffbhvfbbbbbbbbbb', '8980758885', 'shreya@gmail.com', 'manoj', '', ''),
('654', '86558999', NULL, 'gffh', 'ffff@dgj.com', NULL, NULL, NULL),
('9', '989898989', NULL, 'gopal', 'gopal@gmail.com', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sensors`
--

CREATE TABLE IF NOT EXISTS `sensors` (
  `idSensors` varchar(10) NOT NULL,
  `Sensor_Name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sensors`
--

INSERT INTO `sensors` (`idSensors`, `Sensor_Name`) VALUES
('s1', 'Temprature'),
('s2', 'Humidity'),
('s3', 'proximity'),
('s4', 'light'),
('s5', 'occupancy'),
('s6', 'ir');

-- --------------------------------------------------------

--
-- Table structure for table `switches`
--

CREATE TABLE IF NOT EXISTS `switches` (
  `idSwitches` int(2) NOT NULL,
  `SwitchBoard_ID` bigint(8) NOT NULL,
  `Device_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `switches`
--

INSERT INTO `switches` (`idSwitches`, `SwitchBoard_ID`, `Device_ID`) VALUES
(1, 4126, 1),
(2, 4126, 2),
(3, 4126, 3),
(4, 4126, 4),
(5, 4126, 5),
(6, 4126, 6),
(7, 4126, 7),
(8, 4126, 8),
(1, 7124, 1),
(2, 7124, 2),
(3, 7124, 3),
(4, 7124, 4),
(5, 7124, 5),
(6, 7124, 6),
(7, 7124, 7),
(8, 7124, 8),
(1, 7129, 1),
(2, 7129, 2),
(3, 7129, 3),
(4, 7129, 4),
(5, 7129, 5),
(6, 7129, 6),
(7, 7129, 7),
(8, 7129, 8),
(1, 4123, 1),
(2, 4123, 2),
(3, 4123, 3),
(4, 4123, 4),
(5, 4123, 5),
(6, 4123, 6),
(7, 4123, 7),
(8, 4123, 8),
(1, 6125, 1),
(2, 6125, 2),
(3, 6125, 3),
(4, 6125, 4),
(5, 6125, 5),
(6, 6125, 6),
(7, 6125, 7),
(8, 6125, 8),
(1, 7127, 1),
(2, 7127, 2),
(3, 7127, 3),
(4, 7127, 4),
(5, 7127, 5),
(6, 7127, 6),
(7, 7127, 7),
(8, 7127, 8),
(1, 6128, 1),
(2, 6128, 2),
(3, 6128, 3),
(4, 6128, 4),
(5, 6128, 5),
(6, 6128, 6),
(7, 6128, 7),
(8, 6128, 8),
(1, 445, 1);

-- --------------------------------------------------------

--
-- Table structure for table `switch_boards`
--

CREATE TABLE IF NOT EXISTS `switch_boards` (
  `idSwitch_Boards` bigint(8) NOT NULL,
  `Switch_IP_Address` varchar(15) NOT NULL,
  `Switch_MAC_Address` varchar(45) NOT NULL,
  `Switch_Board_Price` bigint(8) NOT NULL,
  `Master_User_ID` int(10) NOT NULL,
  `No_Of_Device` bigint(8) NOT NULL,
  `Rooms_ID` bigint(4) NOT NULL,
  `switchboard name` varchar(30) DEFAULT NULL,
  `brightness` bigint(8) DEFAULT NULL,
  `temperature` bigint(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `switch_boards`
--

INSERT INTO `switch_boards` (`idSwitch_Boards`, `Switch_IP_Address`, `Switch_MAC_Address`, `Switch_Board_Price`, `Master_User_ID`, `No_Of_Device`, `Rooms_ID`, `switchboard name`, `brightness`, `temperature`) VALUES
(445, '344.54.54.44', '4545.3444.34.34.', 45564, 3, 5, 34, NULL, 75, 34),
(4123, '172:12:0:1', '13:14:15:16', 4000, 1, 0, 1, NULL, 75, 34),
(4126, '172:12:0:4', '13:14:15:19', 4000, 2, 0, 2, NULL, 77, 40),
(6125, '172:12:0:3', '13:14:15:18', 6000, 2, 0, 3, NULL, 75, 34),
(6128, '172:12:0:6', '13:14:15:21', 6000, 3, 0, 2, NULL, 75, 34),
(7124, '172:12:0:2', '13:14:15:17', 7000, 1, 0, 1, NULL, 75, 34),
(7127, '172:12:1:5', '13:14:15:20', 7000, 2, 0, 3, NULL, 78, 25),
(7129, '172:12:0:7', '13:14:15:22', 7000, 3, 0, 6, NULL, 75, 34);

--
-- Triggers `switch_boards`
--
DELIMITER $$
CREATE TRIGGER `sw` AFTER INSERT ON `switch_boards`
 FOR EACH ROW BEGIN
 SET @x = 0;
     insertLoop: LOOP
       SET @x = @x + 1;
       
       INSERT INTO `switches`(`idSwitches`, `SwitchBoard_ID`, `Device_ID`) VALUES (@x,new.idSwitch_Boards,@x);
       
       IF @x < 9 THEN
         ITERATE insertLoop;
       END IF;
       LEAVE insertLoop;
     END LOOP insertLoop;
  END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `working_scenario`
--

CREATE TABLE IF NOT EXISTS `working_scenario` (
  `Date` date NOT NULL,
  `Start_Time` time NOT NULL,
  `End_Time` time NOT NULL,
  `No_Of_Time_Switch_ON` bigint(20) NOT NULL,
  `No_Of_Time_Switch_OFF` bigint(20) NOT NULL,
  `No_Of_Time_App_ON` bigint(20) NOT NULL,
  `No_Of_Time_App_OFF` bigint(20) NOT NULL,
  `Sensor_Value` float NOT NULL,
  `Sensor_ID` varchar(10) NOT NULL,
  `Switch_Board_ID` bigint(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `working_scenario`
--

INSERT INTO `working_scenario` (`Date`, `Start_Time`, `End_Time`, `No_Of_Time_Switch_ON`, `No_Of_Time_Switch_OFF`, `No_Of_Time_App_ON`, `No_Of_Time_App_OFF`, `Sensor_Value`, `Sensor_ID`, `Switch_Board_ID`) VALUES
('2015-05-25', '12:41:44', '03:00:00', 5, 3, 1, 0, 50, 's2', 6125),
('2015-05-25', '03:00:00', '06:00:00', 4, 12, 0, 4, 45.98, 's4', 7124),
('2015-05-25', '06:00:00', '09:00:00', 5, 4, 0, 12, 6555, 's5', 6125),
('2015-06-05', '17:20:20', '17:20:23', 5, 0, 3, 2, 34, 's3', 4123),
('2015-06-05', '17:20:40', '17:20:43', 5, 0, 3, 2, 34, 's3', 4123),
('2015-06-05', '17:21:00', '17:21:03', 5, 0, 3, 2, 34, 's3', 4123),
('2015-06-05', '17:21:20', '17:21:23', 5, 0, 3, 2, 34, 's3', 4123),
('2015-06-05', '17:21:40', '17:21:43', 5, 0, 3, 2, 34, 's3', 4123),
('2015-06-05', '17:22:00', '17:22:03', 5, 0, 3, 2, 34, 's3', 4123);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_ID`), ADD KEY `Re` (`Reference_ID`), ADD KEY `swi` (`Switch_BoardID`);

--
-- Indexes for table `bill_payment`
--
ALTER TABLE `bill_payment`
  ADD PRIMARY KEY (`idBill_Payment`), ADD KEY `User_ID_idx` (`User_ID`);

--
-- Indexes for table `consumption`
--
ALTER TABLE `consumption`
  ADD KEY `needs_idx` (`Switch_Board_ID`);

--
-- Indexes for table `device_information`
--
ALTER TABLE `device_information`
  ADD PRIMARY KEY (`idDevice`);

--
-- Indexes for table `home`
--
ALTER TABLE `home`
  ADD PRIMARY KEY (`idHome`);

--
-- Indexes for table `master_user`
--
ALTER TABLE `master_user`
  ADD PRIMARY KEY (`idUser_Information`), ADD UNIQUE KEY `App_IP` (`App_IP`), ADD KEY `Home_ID_idx` (`Home__ID`), ADD KEY `Home__ID` (`Home__ID`), ADD KEY `Home__ID_2` (`Home__ID`);

--
-- Indexes for table `reference_switchboards`
--
ALTER TABLE `reference_switchboards`
  ADD KEY `Reference__UserID` (`Reference__UserID`), ADD KEY `SwitchBoard_ID` (`SwitchBoard_ID`), ADD KEY `Reference__UserID_2` (`Reference__UserID`), ADD KEY `SwitchBoard_ID_2` (`SwitchBoard_ID`);

--
-- Indexes for table `reference_user`
--
ALTER TABLE `reference_user`
  ADD PRIMARY KEY (`idReference_User`), ADD UNIQUE KEY `App_ID_Mac` (`App_ID_Mac`), ADD UNIQUE KEY `IP_ADD` (`IP_ADD`);

--
-- Indexes for table `sensors`
--
ALTER TABLE `sensors`
  ADD PRIMARY KEY (`idSensors`);

--
-- Indexes for table `switches`
--
ALTER TABLE `switches`
  ADD KEY `are in_idx` (`SwitchBoard_ID`), ADD KEY `has_idx` (`Device_ID`);

--
-- Indexes for table `switch_boards`
--
ALTER TABLE `switch_boards`
  ADD PRIMARY KEY (`idSwitch_Boards`), ADD KEY `fk_User_idx` (`Master_User_ID`);

--
-- Indexes for table `working_scenario`
--
ALTER TABLE `working_scenario`
  ADD KEY `has_idx` (`Sensor_ID`), ADD KEY `needs_idx` (`Switch_Board_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `master_user`
--
ALTER TABLE `master_user`
  MODIFY `idUser_Information` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
ADD CONSTRAINT `Reference_User` FOREIGN KEY (`Reference_ID`) REFERENCES `reference_user` (`idReference_User`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `Switch_Boards` FOREIGN KEY (`Switch_BoardID`) REFERENCES `switch_boards` (`idSwitch_Boards`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bill_payment`
--
ALTER TABLE `bill_payment`
ADD CONSTRAINT `fk_master` FOREIGN KEY (`User_ID`) REFERENCES `master_user` (`idUser_Information`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `consumption`
--
ALTER TABLE `consumption`
ADD CONSTRAINT `needs` FOREIGN KEY (`Switch_Board_ID`) REFERENCES `switch_boards` (`idSwitch_Boards`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `master_user`
--
ALTER TABLE `master_user`
ADD CONSTRAINT `master_user_ibfk_1` FOREIGN KEY (`Home__ID`) REFERENCES `home` (`idHome`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reference_switchboards`
--
ALTER TABLE `reference_switchboards`
ADD CONSTRAINT `fk_reference` FOREIGN KEY (`Reference__UserID`) REFERENCES `reference_user` (`idReference_User`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `fk_switchboard` FOREIGN KEY (`SwitchBoard_ID`) REFERENCES `switch_boards` (`idSwitch_Boards`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `switches`
--
ALTER TABLE `switches`
ADD CONSTRAINT `fk_are in` FOREIGN KEY (`SwitchBoard_ID`) REFERENCES `switch_boards` (`idSwitch_Boards`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `fk_has` FOREIGN KEY (`Device_ID`) REFERENCES `device_information` (`idDevice`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `switch_boards`
--
ALTER TABLE `switch_boards`
ADD CONSTRAINT `master_fk` FOREIGN KEY (`Master_User_ID`) REFERENCES `master_user` (`idUser_Information`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `working_scenario`
--
ALTER TABLE `working_scenario`
ADD CONSTRAINT `fk_sensor_ID` FOREIGN KEY (`Sensor_ID`) REFERENCES `sensors` (`idSensors`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `fk_switch_board_ID` FOREIGN KEY (`Switch_Board_ID`) REFERENCES `switch_boards` (`idSwitch_Boards`) ON DELETE CASCADE ON UPDATE CASCADE;

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`root`@`localhost` EVENT `consumption a day` ON SCHEDULE EVERY 1 DAY STARTS '2015-06-05 00:00:00' ENDS '2015-06-06 00:00:00' ON COMPLETION PRESERVE ENABLE DO INSERT INTO `consumption`(`Consumption_A_Day`, `Switch_Board_ID`, `Consumption_Date`, `switch_ID`) VALUES ("54","7127",CURRENT_DATE,"3")$$

CREATE DEFINER=`root`@`localhost` EVENT `workin scenario` ON SCHEDULE EVERY 20 SECOND STARTS '2015-06-05 17:20:00' ENDS '2015-06-05 18:00:00' ON COMPLETION PRESERVE DISABLE DO INSERT INTO `working_scenario` (`Date`, `Start_Time`, `End_Time`, `No_Of_Time_Switch_ON`, `No_Of_Time_Switch_OFF`, `No_Of_Time_App_ON`, `No_Of_Time_App_OFF`, `Sensor_Value`, `Sensor_ID`, `Switch_Board_ID`) VALUES (CURRENT_DATE,CURRENT_TIME, CURRENT_TIME+"03:00:00", "5","0", "3", "2", "34", "s3", "4123")$$

DELIMITER ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
