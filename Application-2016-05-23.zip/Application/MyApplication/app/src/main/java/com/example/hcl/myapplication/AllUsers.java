package com.example.hcl.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AllUsers extends Activity {
    // List<String> r = new ArrayList<String>();
    TextView text;
    ListView list11;
    // LinearLayout li;
    public String[] list1, list2, list3;
    public static final String MY_PREFS_NAME = "enerleaf0";
    String name1, name2;
    private static String url = "http://192.168.10.38/CI/index.php/login1/allusers";
    JSONParser jsonParser = new JSONParser();
    JSONObject json;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_all_users);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        list11 = (ListView) findViewById(R.id.listView11);

        connect();
    }



    private void connect() {
        String data;


       try {
            SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);

            String name1 = prefs.getString("userid", "");//"No name defined" is the default value.
           Log.d("name",name1);
            //  String name2 = prefs.getString("name2", "No");
            //  String name2 = prefs.getString("password", "");
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("Authentication_Id", name1));

            Log.d("request!", "in baCK" + params.toString());
            Log.d("request!", "starting");


          //  json = jsonParser.makeHttpRequest(LOGIN_URL, "GET", params);
            DefaultHttpClient client = new DefaultHttpClient();
           // HttpGet request = new HttpGet(url);
           String paramString = URLEncodedUtils.format(params, "utf-8");
           url += "?" + paramString;
           HttpGet httpGet = new HttpGet(url);
            HttpResponse response = client.execute(httpGet);

            HttpEntity entity=response.getEntity();
            data= EntityUtils.toString(entity);
            Log.e("STRING", data);


            try {

               // data = json.toString();
               // JSONObject jo = new JSONObject(data);
                JSONArray ja = new JSONArray(data);
              //  JSONObject jo1 = new JSONObject(data);
               // JSONObject father1 = jo1.getJSONObject("0");
                JSONObject father1 = null;

                list1 = new String[ja.length()];
                list2 = new String[ja.length()];
                list3 = new String[ja.length()];
                for (int i = 0; i < ja.length(); i++) {

                    father1 = ja.getJSONObject(i);
                    list1[i] = father1.getString("idSwitch_Boards");
                    list2[i] = father1.getString("Authentication_ID");
                    list3[i] = father1.getString("Reference_Authentication_ID");

                    if((list2[i].compareToIgnoreCase(String.valueOf(name1)) == 0))
                    {
                        list2[i] = "me";

                    }
                    if(list3[i].compareToIgnoreCase(String.valueOf(name1)) == 0)
                    {
                        list3[i] = "me";
                    }
                    Log.d("name",list2[i]);


                    list11.setAdapter(new ListViewAct(this, list1, list2, list3));
                }

            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        } catch (ClientProtocolException e) {
            Log.d("HTTPCLIENT", e.getLocalizedMessage());
        } catch (IOException e) {
            Log.d("HTTPCLIENT", e.getLocalizedMessage());
        }


    }


        class ListViewAct extends ArrayAdapter<String> {

            private final Context context;
            private final String[] values1;
            private final String[] values2;
            private final String[] values3;

            public ListViewAct(Context context, String[] object1, String[] object2, String[] object3) {
                super(context, R.layout.activity_main, object2);
                this.context = context;
                this.values1 = object1;
                this.values2 = object2;
                this.values3 = object3;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

                View rowView = inflater.inflate(R.layout.allusers, parent, false);

                TextView textView1 = (TextView) rowView.findViewById(R.id.switchid);
                TextView textView2 = (TextView) rowView.findViewById(R.id.muid);
                TextView textView3 = (TextView) rowView.findViewById(R.id.ruid);
                textView1.setText(values1[position]);
                textView2.setText(values2[position]);
                textView3.setText(values3[position]);
                if(textView2.getText().toString() == "me")
                {  textView2.setBackgroundColor(Color.parseColor("#ff000000"));
                textView2.setTextColor(Color.parseColor("#ffffffff"));}
                if(textView3.getText().toString() == "me")
                { textView3.setBackgroundColor(Color.parseColor("#ff000000"));
                textView3.setTextColor(Color.parseColor("#ffffffff"));}
                return rowView;
            }
        }

    }
