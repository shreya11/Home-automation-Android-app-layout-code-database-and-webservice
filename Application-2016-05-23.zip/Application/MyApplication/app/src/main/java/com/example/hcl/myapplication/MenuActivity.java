package com.example.hcl.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;


public class MenuActivity extends Activity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Button b1 = (Button) findViewById(R.id.switchboard1);
        Button b2 = (Button) findViewById(R.id.userlist);
        Button b3 = (Button) findViewById(R.id.settings);
        Button b4 = (Button) findViewById(R.id.highalert);
        Button b5 = (Button) findViewById(R.id.ref_req);

        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.switchboard1: {
                Intent myIntent = new Intent(v.getContext(), AddSwitchBoard.class);
                startActivityForResult(myIntent, 0);
                break;
            }
            case R.id.userlist: {
                Intent myIntent = new Intent(v.getContext(), AllUsers.class);
                startActivityForResult(myIntent, 0);
                break;
            }
            case R.id.settings: {
                Intent myIntent = new Intent(v.getContext(), com.example.hcl.myapplication.SettingsActivity.class);
                startActivityForResult(myIntent, 0);
                break;
            }
            case R.id.highalert:{
                Intent myIntent = new Intent(v.getContext(), MainActivity.class);
                startActivityForResult(myIntent, 0);
                break;
            }
            case R.id.ref_req:{
                Intent myIntent = new Intent(v.getContext(), Reference.class);
                startActivityForResult(myIntent, 0);
                break;
            }
        }

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
