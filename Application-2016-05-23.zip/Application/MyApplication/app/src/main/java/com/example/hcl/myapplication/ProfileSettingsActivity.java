package com.example.hcl.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class ProfileSettingsActivity extends Activity implements View.OnClickListener {
    EditText input, input1;
    //  TextView text;
    //  ListView list11;
    // LinearLayout li;
    public String list1;
    public String list2;
    public String list3;
    public String list4;
    // JSONObject json;
    EditText username;
    EditText emailid;
    EditText contactnumber;
    EditText postaladdress;
    Button saveB;
    public static final String TAG_SUCCESS = "json";
    JSONParser jsonParser = new JSONParser();
    private static final String url = "http://192.168.10.38/CI/index.php/login1/proset";
    private static final String LOGIN_URL = "http://192.168.10.38/CI/index.php/login1/save";
    public static final String MY_PREFS_NAME = "enerleaf0";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_settings);

        username = (EditText) findViewById(R.id.userName);
        emailid = (EditText) findViewById(R.id.eMailId);
        emailid.setFocusable(false);


        contactnumber = (EditText) findViewById(R.id.contactNumber);


        postaladdress = (EditText) findViewById(R.id.postalAddress);

        final TextView changepassword = (TextView) findViewById(R.id.changePassword);

        changepassword.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent myIntent2 = new Intent(changepassword.getContext(), com.example.hcl.myapplication.ChangePassword.class);
                startActivityForResult(myIntent2, 0);

            }
        });

        new connect1().execute();
       saveB = (Button) findViewById(R.id.saveChanges);
        saveB.setOnClickListener(this);
    }

   /* private void alert() {


        AlertDialog.Builder alert = new AlertDialog.Builder(ProfileSettingsActivity.this);
        LinearLayout lila1 = new LinearLayout(this);
        lila1.setOrientation(LinearLayout.VERTICAL); //1 is for vertical orientation
        alert.setTitle("Please login"); //Set Alert dialog title here
        alert.setMessage("emailid & password"); //Message here

        input = new EditText(ProfileSettingsActivity.this);
        input1 = new EditText(ProfileSettingsActivity.this);
        lila1.addView(input);



        lila1.addView(input1);
        alert.setView(lila1);
        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                if(input.getText().toString().trim().length() <= 0 || input1.getText().toString().trim().length() <= 0)
                {

                            Toast.makeText(getBaseContext(), "wrong thing entered", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(ProfileSettingsActivity.this, ProfileSettingsActivity.class);
                    startActivity(intent);
                    finish();
                }
                else
                new connect1().execute();
            }
        }); //End of alert.setPositiveButton
        alert.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // Canceled.
                dialog.cancel();
            }
        }); //End of alert.setNegativeButton
        AlertDialog alertDialog = alert.create();
        alertDialog.show();

    }*/

    @Override
    public void onClick(View v) {
        new save1().execute();
    }


    class connect1 extends AsyncTask<String, String, String>  {
        String data1;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... args) {

           // String email = input.getEditableText().toString();
           // String pass = input1.getEditableText().toString();
            SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);

            String email = prefs.getString("userid", "");//"No name defined" is the default value.
            String pass = prefs.getString("password", "");
            Log.d("name",email);




            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("Email", email));
            params.add(new BasicNameValuePair("password", pass));
            Log.d("request!", "starting");
            Log.d("data", params.toString());
            Log.d("run","yahhoooo");

            JSONObject json = jsonParser.makeHttpRequest(url, "POST", params);

            Log.d("request!", "in baCK" + json.toString());
            //  json = new JSONObject(data1);
            Log.d("my app", "in try");


            try{

                int success = json.getInt("success");



                if(success == 1) {
                    data1 = json.toString();
                    JSONObject jo = new JSONObject(data1);
                    JSONObject father = jo.getJSONObject("0");

                    list1 = father.getString("User_Name");
                    list2 = father.getString("Contact_Number");
                    list3 = father.getString("User_Address");
                    list4 = father.getString("Authentication_ID");
                    ProfileSettingsActivity.this.runOnUiThread(new Runnable() {


                        @Override
                        public void run() {
                            username.setText(list1, TextView.BufferType.EDITABLE);
                            contactnumber.setText(list2, TextView.BufferType.EDITABLE);
                            postaladdress.setText(list3, TextView.BufferType.EDITABLE);
                            emailid.setText(list4, TextView.BufferType.EDITABLE);
                        }
                    });
                }
                else
                {
                    ProfileSettingsActivity.this.runOnUiThread(new Runnable(){


                        @Override
                        public void run() {
                            Toast.makeText(getBaseContext(), "wrong thing entered", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(ProfileSettingsActivity.this, ProfileSettingsActivity.class);
                            startActivity(intent);
                            finish();


                        }
                    });
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }


    }

    private class save1 extends AsyncTask<String, String, String> {

String data2;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... args) {
            // TODO Auto-generated method stub


            String userName = username.getText().toString();
            String contact = contactnumber.getText().toString();
            String address = postaladdress.getText().toString();
            String email = emailid.getText().toString();
            Log.d("my app", "do in back after init");
            // String password = pass.getText().toString();


            List<NameValuePair> params1 = new ArrayList<NameValuePair>();




            params1.add(new BasicNameValuePair("name", userName));
            params1.add(new BasicNameValuePair("number", contact));
            params1.add(new BasicNameValuePair("address", address));
            params1.add(new BasicNameValuePair("email", email));
            Log.d("request!", "in baCK" + params1.toString());
            Log.d("request!", "starting");


           JSONObject json1 = jsonParser.makeHttpRequest(LOGIN_URL, "POST", params1);
            // String s = null;
            Log.d("my app", "   hhhh    " + json1.toString());


            try {
                int success = json1.getInt("success");
                //String message = json.getString(TAG_MESSAGE);
                // s = json.getString(TAG_SUCCESS);
                //  Log.d("Msg", json.getString(TAG_INFO));
                if (success == 1) {

                    ProfileSettingsActivity.this.runOnUiThread(new Runnable() {


                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "successfully saved!", Toast.LENGTH_LONG).show();

                        }
                    });

                    data2 = json1.toString();
                    JSONObject jo1 = new JSONObject(data2);
                    JSONObject father1 = jo1.getJSONObject("0");

                  final String list11 = father1.getString("User_Name");
                final  String  list12 = father1.getString("Contact_Number");
                  final  String    list13 = father1.getString("User_Address");
                 final String  list14 = father1.getString("Authentication_ID");
                    ProfileSettingsActivity.this.runOnUiThread(new Runnable() {


                        @Override
                        public void run() {
                            username.setText(list11, TextView.BufferType.EDITABLE);
                            contactnumber.setText(list12, TextView.BufferType.EDITABLE);
                            postaladdress.setText(list13, TextView.BufferType.EDITABLE);
                            emailid.setText(list14, TextView.BufferType.EDITABLE);
                        }
                    });
                }
                else if (success == 0) {

                    ProfileSettingsActivity.this.runOnUiThread(new Runnable() {


                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "try again!", Toast.LENGTH_LONG).show();
                        }
                    });


                    //       Log.d("Login Failure!", json1.getString(TAG_SUCCESS));
//
                    //      return json1.getString(TAG_SUCCESS);


                }


                } catch (JSONException e1) {
                e1.printStackTrace();
            }



            return null;

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main11, menu);
        return true;
    }

}