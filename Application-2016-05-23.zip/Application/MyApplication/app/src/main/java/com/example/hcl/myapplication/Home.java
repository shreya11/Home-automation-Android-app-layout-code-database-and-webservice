package com.example.hcl.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class Home extends Activity implements View.OnClickListener {
    JSONParser jsonParser = new JSONParser();
    JSONObject json;
    private static final String url1 = "http://192.168.10.38/CI/index.php/login1/seekbar";
    private static final String url2 = "http://192.168.10.38/CI/index.php/login1/seekbar1";
    private static final String url3 = "http://192.168.10.38/CI/index.php/login1/getBS";
    public static final String MY_PREFS_NAME = "enerleafH";
    String msg = "Android : ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Button menu = (Button) findViewById(R.id.menu);
        menu.setOnClickListener(this);

        ListView lv = (ListView) findViewById(R.id.list1);
        lv.setAdapter(new ListAdapter(Home.this));
    }


    @Override
    public void onClick(View v) {
        Intent myIntent = new Intent(v.getContext(), MenuActivity.class);
        startActivityForResult(myIntent, 0);
    }


    private class ListAdapter extends BaseAdapter {
        private Context con;
        private int size;
        SharedPreferences prefs2 = getSharedPreferences("enerleaf11", MODE_PRIVATE);
        String str = prefs2.getString(size + "switchboard", "");
        private int s[] = new int[str.length()];
        private int s1[] = new int[str.length()];

        String[] li;


        public ListAdapter(Home mainActivity) {
            // TODO Auto-generated constructor stub
            this.con = mainActivity;
            for (int i = 0; i < str.length(); ++i) {
                s[i] = 0;
                s1[i] = 0;
            }

        }


        @Override
        public int getCount() {
            // TODO Auto-generated method stub

            return str.length();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return null;
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        protected int dohere(){
            new getbs().execute();
            final int[] a = new int[str.length()];
            SharedPreferences prefs2 = getSharedPreferences("good", MODE_PRIVATE);
            int str1 = prefs2.getInt("bright", 0);
            for(int i=0;i<str.length();i++)
            {
                a[i] = str1;
                str1 = a[i];
            }

            //swid.setText(str);

            return str1;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub

            LayoutInflater inflater = LayoutInflater.from(this.con);
            View View = inflater.inflate(R.layout.row, null);
            SeekBar brightness = (SeekBar) View.findViewById(R.id.seekBar1);
            SeekBar temperature = (SeekBar) View.findViewById(R.id.temperature);

            final TextView btnseek = (TextView) View.findViewById(R.id.count);
            final TextView temp = (TextView) View.findViewById(R.id.tempvalue);
            final TextView swid = (TextView) View.findViewById(R.id.swiid);
            //  SharedPreferences pref2 = PreferenceManager.getDefaultSharedPreferences(con);
            SharedPreferences prefs2 = getSharedPreferences("enerleaf11", MODE_PRIVATE);
            String str = prefs2.getString(position + "switchboard", "");
            Log.d("le", str);
            swid.setText(str);




                brightness.setProgress(s[position]);
                btnseek.setText("" + s[position]);


                temp.setText("" + s1[position]);
                temperature.setProgress(s1[position]);

            brightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onProgressChanged(SeekBar seekBar, int progress,
                                              boolean fromUser) {
                    // TODO Auto-generated method stub
                    btnseek.setText("" + progress);
                    s[position] = progress;
                    SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
                    editor.clear();

                    String name2 = btnseek.getText().toString();
                    String name3 = swid.getText().toString();
                    editor.putString("brightness", name2);
                    editor.putString("swid", name3);
                    //  editor.putString("password",name2);
                    //    login.putExtra("userid",name1);
                    //    login.putExtra("password",name2);
                    Log.d(msg, "The onPause() event");

                    editor.commit();
                    new bright().execute();
                }


            });

            temperature.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                @Override
                public void onProgressChanged(SeekBar seekBar, int progress,
                                              boolean fromUser) {
                    // TODO Auto-generated method stub
                    temp.setText("" + progress);
                    s1[position] = progress;
                    SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
                    editor.clear();


                    String name2 = temp.getText().toString();
                    String name3 = swid.getText().toString();
                    editor.putString("temperature", name2);
                    editor.putString("swid", name3);
                    //  editor.putString("password",name2);
                    //    login.putExtra("userid",name1);
                    //    login.putExtra("password",name2);
                    Log.d(msg, "The onPause() event");

                    editor.commit();
                    new temperature1().execute();

                }
            });

            return View;
        }


        private class bright extends AsyncTask<String, String, String> {


            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected String doInBackground(String... args) {

                 //  final int position = args[0];
                final
                // TODO Auto-generated method stub
                SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);

                final String name1 = prefs.getString("brightness", "");//"No name defined" is the default value.
                Log.d("name", name1);
                final String name2 = prefs.getString("swid", "");
                //  Log.d("my app", "do in back");
                //  String Show = et.getText().toString();

                Log.d("my app", "do in back after init");
                // String password = pass.getText().toString();

                Log.d("my app", "inside try");
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair("swid", name2));
                params.add(new BasicNameValuePair("brightness", name1));
                Log.d("request!", "in baCK" + params.toString());
                Log.d("request!", "starting");
                if (name2 != "0") {

                    json = jsonParser.makeHttpRequest(url2, "POST", params);
                    // String s = null;
                    Log.d("my app", "   hhhh    " + json.toString());


                    try {
                        int success = json.getInt("success");
                        //String message = json.getString(TAG_MESSAGE);
                        // s = json.getString(TAG_SUCCESS);
                        //  Log.d("Msg", json.getString(TAG_INFO));
                        if (success == 1) {
                            Home.this.runOnUiThread(new Runnable() {


                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "Brightness: " + name1, Toast.LENGTH_LONG).show();
                                    Log.d("myapp", "running");




                                }
                            });


                        } else if (success == 0) {

                            Home.this.runOnUiThread(new Runnable() {


                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "wrong thing entered", Toast.LENGTH_LONG).show();
                                }
                            });


                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        //  Toast.makeText(MainActivity.this, "wrong thing entered", Toast.LENGTH_LONG).show();
                        e.printStackTrace();
                    }
                } else {
                    Home.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "no switchboard", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                return null;

            }
        }

        private class temperature1 extends AsyncTask<String, String, String> {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected String doInBackground(String... args) {

                // TODO Auto-generated method stub
                SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);

                final String name1 = prefs.getString("temperature", "");//"No name defined" is the default value.
                Log.d("name", name1);
                final String name2 = prefs.getString("swid", "");
                //  Log.d("my app", "do in back");
                //  String Show = et.getText().toString();

                Log.d("my app", "do in back after init");
                // String password = pass.getText().toString();

                Log.d("my app", "inside try");
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair("swid", name2));
                params.add(new BasicNameValuePair("temperature", name1));
                Log.d("request!", "in baCK" + params.toString());
                Log.d("request!", "starting");
                if (name2 != "0") {

                    json = jsonParser.makeHttpRequest(url1, "POST", params);
                    // String s = null;
                    Log.d("my app", "   hhhh    " + json.toString());


                    try {
                        int success = json.getInt("success");
                        //String message = json.getString(TAG_MESSAGE);
                        // s = json.getString(TAG_SUCCESS);
                        //  Log.d("Msg", json.getString(TAG_INFO));
                        if (success == 1) {
                            Home.this.runOnUiThread(new Runnable() {


                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "temperature: " + name1, Toast.LENGTH_LONG).show();
                                    Log.d("myapp", "running");


                                }


                            });


                        } else if (success == 0) {

                            Home.this.runOnUiThread(new Runnable() {


                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "wrong thing entered", Toast.LENGTH_LONG).show();
                                }
                            });


                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        //  Toast.makeText(MainActivity.this, "wrong thing entered", Toast.LENGTH_LONG).show();
                        e.printStackTrace();
                    }
                } else {
                    Home.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "no switchboard", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                return null;

            }


        }


        private class getbs extends AsyncTask<String, String, String> {


            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected String doInBackground(String... args) {



                // TODO Auto-generated method stub
                        SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);


                final String name2 = prefs.getString("swid", "");
                //  Log.d("my app", "do in back");
                //  String Show = et.getText().toString();

                Log.d("my app", "do in back after init");
                // String password = pass.getText().toString();

                Log.d("my app", "inside try");
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair("swid", name2));

                Log.d("request!", "in baCK" + params.toString());
                Log.d("request!", "starting");


                    json = jsonParser.makeHttpRequest(url3, "POST", params);
                    // String s = null;
                    Log.d("my app", "   hhhh    " + json.toString());


                    try {
                        String data = json.toString();
                       JSONObject jo = new JSONObject(data);
                        JSONObject j1 = jo.getJSONObject("0");
                      final  int name1 = j1.getInt("brightness");
                      final  int n1 = j1.getInt("temperature");
                        Log.d("goit",json.toString());
                            Home.this.runOnUiThread(new Runnable() {


                                @Override
                                public void run() {


                                    SharedPreferences.Editor editor = getSharedPreferences("good", MODE_PRIVATE).edit();
                                    editor.clear();


                                    editor.putInt("brightness", name1);

                                      editor.putInt("temperature",n1);
                                    //    login.putExtra("userid",name1);
                                    //    login.putExtra("password",name2);
                                    editor.putString("swid",name2);
                                    Log.d(msg, "The onPause() event");

                                    editor.commit();

                                }
                            });



                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        //  Toast.makeText(MainActivity.this, "wrong thing entered", Toast.LENGTH_LONG).show();
                        e.printStackTrace();
                    }


                return null;

            }
        }




    }
}