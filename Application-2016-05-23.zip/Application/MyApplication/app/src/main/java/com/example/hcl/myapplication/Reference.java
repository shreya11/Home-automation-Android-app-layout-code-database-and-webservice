package com.example.hcl.myapplication;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class Reference extends Activity implements View.OnClickListener {
EditText referenceid,referencename,referencecontact,uniqueid;
    Button reference;
    JSONParser jsonParser = new JSONParser();
    private static final String url = "http://192.168.10.38/CI/index.php/login1/reference";
    JSONObject json;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reference);

       referenceid = (EditText) findViewById(R.id.referenceID);
       // String referenceIdText = referenceid.getText().toString();

        referencename = (EditText) findViewById(R.id.referenceName);
      //  String referenceNameText = referencename.getText().toString();

        referencecontact = (EditText) findViewById(R.id.referenceContact);
     //   String referencecontactText = referencecontact.getText().toString();
        uniqueid = (EditText) findViewById(R.id.refunique);
       reference = (Button) findViewById(R.id.referenceRequest);
        reference.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        new Reference1().execute();

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_reference, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    class Reference1 extends AsyncTask<String,String,String> {


        @Override
        protected void onPreExecute(){
            super.onPreExecute();
        }
        @Override
        protected String doInBackground(String... args) {
            SharedPreferences prefs = getSharedPreferences("enerleaf0", MODE_PRIVATE);

            String name1 = prefs.getString("userid", "");//"No name defined" is the default value.
            Log.d("name",name1);
            String refid = referenceid.getText().toString();
            final String refname = referencename.getText().toString();
            String refcontact = referencecontact.getText().toString();
            final String refunique = uniqueid.getText().toString();
            Log.d("my app", "do in back after init");
            // String password = pass.getText().toString();

            Log.d("my app", "inside try");
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("refid", refid));
            params.add(new BasicNameValuePair("master", name1));
            params.add(new BasicNameValuePair("refname", refname));
            params.add(new BasicNameValuePair("refcontact", refcontact));
            params.add(new BasicNameValuePair("refunique", refunique));
            Log.d("request!", "in baCK" + params.toString());
            Log.d("request!", "starting");


            json = jsonParser.makeHttpRequest(url, "POST", params);
            // String s = null;
            Log.d("my app", "   hhhh    " + json.toString());


            try {
                int success = json.getInt("success");
                //String message = json.getString(TAG_MESSAGE);
                // s = json.getString(TAG_SUCCESS);
                //  Log.d("Msg", json.getString(TAG_INFO));
                if (success == 1) {
                    Reference.this.runOnUiThread(new Runnable() {


                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "successfully sent the request!", Toast.LENGTH_LONG).show();
                            Log.d("myapp","running");
                           referenceid.setText(null);
                            referencename.setText(null);
                            referencecontact.setText(null);
                            uniqueid.setText(null);




                        }


                    });



                } else if (success == 0) {

                    Reference.this.runOnUiThread(new Runnable() {


                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "enter unique UserID", Toast.LENGTH_LONG).show();
                            uniqueid.setText(null);
                        }
                    });
                }
                    else if(success == -1){
                    Reference.this.runOnUiThread(new Runnable() {


                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), refname+" is already your reference user", Toast.LENGTH_LONG).show();
                        }
                    });
                    }





            } catch (JSONException e) {
                // TODO Auto-generated catch block
                //  Toast.makeText(MainActivity.this, "wrong thing entered", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }


            return null;
        }
    }
}
