package com.example.hcl.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends Activity implements View.OnClickListener {
    private View view;


    // JSON parser class
    public static final String MY_PREFS_NAME = "enerleaf0";
    JSONParser jsonParser = new JSONParser();
    private static final String LOGIN_URL = "http://192.168.10.38/CI/index.php/login1/login11";
    //JSON element ids from repsonse of php script:
    // private ProgressDialog pDialog;
    //StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    String msg = "Android : ";
    EditText emailid, pass;
   public static final String TAG_SUCCESS = "success";
    public static final String TAG_MESSAGE = "message";
    private static final String TAG_INFO = "info";
    JSONObject json;
    Intent login;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Progress Dialog


        emailid = (EditText) findViewById(R.id.Authentication_Id);
        //String eMailText = emailid.getText().toString();
        Log.d("my app", "start of app");
        pass = (EditText) findViewById(R.id.Password);
        //   String passWordText = password.getText().toString();

        Button signin = (Button) findViewById(R.id.signIn);
        signin.setOnClickListener(this);

        TextView signup = (TextView) findViewById(R.id.signUp);
        signup.setOnClickListener(this);

        signin.setOnClickListener(this);
        SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);

        String name1 = prefs.getString("userid", "");//"No name defined" is the default value.
        //  String name2 = prefs.getString("name2", "No");
        String name2 = prefs.getString("password", "");
        emailid.setText(name1);
        pass.setText(name2);

        Log.d(msg,"onCreate");

    }
    @Override
    protected void onStart() {
        super.onStart();

        SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);

        String name1 = prefs.getString("userid", "");//"No name defined" is the default value.
        //  String name2 = prefs.getString("name2", "No");
        String name2 = prefs.getString("password", "");
        emailid.setText(name1);
        pass.setText(name2);

        Log.d(msg,"onStart"+name1+name2);

    }


    @Override
    protected void onResume() {
        super.onResume();

        SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);

            String name1 = prefs.getString("userid", "");//"No name defined" is the default value.
            //  String name2 = prefs.getString("name2", "No");
            String name2 = prefs.getString("password", "");
            emailid.setText(name1);
              pass.setText(name2);
        Log.d(msg,"onResume");

    }

    @Override
    protected void onPause() {
        super.onPause();

            SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
        editor.clear();

                String name1 = emailid.getText().toString();
                String name2 = pass.getText().toString();

                editor.putString("userid", name1);
                editor.putString("password",name2);
    //    login.putExtra("userid",name1);
    //    login.putExtra("password",name2);
                Log.d(msg, "The onPause() event");

            editor.commit();

        }

    @Override
    public void onStop() {
        super.onStop();

        SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();

            editor.clear();
                String name1 = emailid.getText().toString();
                String name2 = pass.getText().toString();
                editor.putString("userid", name1);
        editor.putString("password",name2);
     //   login.putExtra("userid",name1);
     //   login.putExtra("password",name2);
                Log.d(msg, "The onStop() event");

            editor.commit();

        }

    @Override
    public void onDestroy() {
        super.onDestroy();

            SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();

            editor.clear();
            String name1 = emailid.getText().toString();
        String name2 = pass.getText().toString();
                editor.putString("userid", name1);
        editor.putString("password", name2);
       // login.putExtra("userid",name1);
      //  login.putExtra("password",name2);
                Log.d(msg, "The onDestroy() event");

            editor.commit();


        }



    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.signUp: {
                Intent myIntent = new Intent(v.getContext(), com.example.hcl.myapplication.SignUpActivity.class);
                startActivityForResult(myIntent, 0);
                break;
            }
            case R.id.signIn: {
                new AttemptLogin().execute();
                // TODO Auto-generated method stub
            }

            break;
        }
    }




    class AttemptLogin extends AsyncTask<String, String, String> {




        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }
        @Override
        protected String doInBackground(String... args) {
            // TODO Auto-generated method stub

            Log.d("my app", "do in back");
            String userId = emailid.getText().toString();
            Log.d("my app", "do in back after init");
            String password = pass.getText().toString();

                Log.d("my app", "inside try");
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                params.add(new BasicNameValuePair("Authentication_Id", userId));
                params.add(new BasicNameValuePair("password", password));
                Log.d("request!", "in baCK" + params.toString());
                Log.d("request!", "starting");



                json = jsonParser.makeHttpRequest(LOGIN_URL, "POST", params);
              // String s = null;
           Log.d("my app","   hhhh    "+json.toString());


            try {
               int success = json.getInt(TAG_SUCCESS);
               //String message = json.getString(TAG_MESSAGE);
                   // s = json.getString(TAG_SUCCESS);
                  //  Log.d("Msg", json.getString(TAG_INFO));
                    if (success == 1) {
                        login = new Intent(getApplicationContext(), Home.class);
                        login.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                        startActivityForResult(login, 0);
                    }
                  else if(success == 0){

                        MainActivity.this.runOnUiThread(new Runnable(){


                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), "wrong thing entered", Toast.LENGTH_LONG).show();
                            }
                        });

                        Log.d("Login Failure!", json.getString(TAG_SUCCESS));
//
                       return json.getString(TAG_SUCCESS);




                 }
                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                Toast.makeText(MainActivity.this, "wrong thing entered", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }

                return null;

        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
     //       finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



}