
package com.example.hcl.myapplication;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class ChangePassword extends Activity implements View.OnClickListener {
    JSONParser jsonParser = new JSONParser();
    private static final String LOGUP_URL = "http://192.168.10.38/CI/index.php/login1/changepassword";
    JSONObject json;
    EditText oldpassword,newpassword,confirmpassword,input;
    public static final String MY_PREFS_NAME = "enerleaf0";
    public static final String TAG_SUCCESS = "success";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

         oldpassword = (EditText) findViewById(R.id.oldPassword);
     //   String oldPasswordText = oldpassword.getText().toString();
            newpassword = (EditText) findViewById(R.id.newPassword);
    //    String newPasswordText = newpassword.getText().toString();
            confirmpassword = (EditText) findViewById(R.id.confirmPassword);
    //    String confirmPasswordText = confirmpassword.getText().toString();

        final Button savepassword = (Button) findViewById(R.id.savePassword);
        savepassword.setOnClickListener(this);


        savepassword.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new changepassword().execute();

            }
        });

    }
 /*   private void alert() {


        AlertDialog.Builder alert = new AlertDialog.Builder(ChangePassword.this);
        LinearLayout lila1 = new LinearLayout(this);
        lila1.setOrientation(LinearLayout.VERTICAL); //1 is for vertical orientation
        alert.setTitle("Please login"); //Set Alert dialog title here
        alert.setMessage("emailid"); //Message here

        input = new EditText(ChangePassword.this);


        alert.setView(input);
        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                new changepassword().execute();
            }
        }); //End of alert.setPositiveButton
        alert.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // Canceled.
                dialog.cancel();
            }
        }); //End of alert.setNegativeButton
        AlertDialog alertDialog = alert.create();
        alertDialog.show();

    }*/

    class changepassword extends AsyncTask<String, String, String> {


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }
        @Override
        protected String doInBackground(String... args) {
            // TODO Auto-generated method stub
            SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);

            String email = prefs.getString("userid", "");//"No name defined" is the default value.
          //  String pass = prefs.getString("password", "");
            Log.d("name",email);
            //String email = input.getEditableText().toString();
            Log.d("my app", "do in back");
            String oldPass = oldpassword.getText().toString();
            Log.d("my app", "do in back after init");
            String newPass = newpassword.getText().toString();
            String confirmPass = confirmpassword.getText().toString();

            Log.d("my app", "inside try");
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("email",email));
            params.add(new BasicNameValuePair("oldpassword", oldPass));
            params.add(new BasicNameValuePair("newpassword", newPass));
            params.add(new BasicNameValuePair("confirmpassword", confirmPass));

            Log.d("my app", "after phn");

            Log.d("request!", "in baCK" + params.toString());
            Log.d("request!", "starting");



            json = jsonParser.makeHttpRequest(LOGUP_URL, "POST", params);
            // String s = null;
            Log.d("my app","   hhhh    "+json.toString());


            try {
                int success = json.getInt(TAG_SUCCESS);
                //String message = json.getString(TAG_MESSAGE);
                // s = json.getString(TAG_SUCCESS);
                //  Log.d("Msg", json.getString(TAG_INFO));
                if (success == 1) {

                    ChangePassword.this.runOnUiThread(new Runnable(){


                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "successfully saved password", Toast.LENGTH_LONG).show();
                        }
                    });

                }
                else if(success == 0) {

                    ChangePassword.this.runOnUiThread(new Runnable() {


                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "wrong password", Toast.LENGTH_LONG).show();
                        }
                    });
                }
                    else
                    {  ChangePassword.this.runOnUiThread(new Runnable() {


                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "wrong email address", Toast.LENGTH_LONG).show();
                        }
                    });

                    }





            } catch (JSONException e) {
                // TODO Auto-generated catch block
                //  Toast.makeText(MainActivity.this, "wrong thing entered", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }

            return null;

        }


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_change_password, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onClick(View v) {

    }
}
