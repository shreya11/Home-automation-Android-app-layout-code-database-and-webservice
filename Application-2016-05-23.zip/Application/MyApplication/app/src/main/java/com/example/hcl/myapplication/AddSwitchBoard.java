package com.example.hcl.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static com.example.hcl.myapplication.R.id.label;

public class AddSwitchBoard extends Activity implements View.OnClickListener {

    List<String> li;
    ListView list;
    private View view;
    JSONParser jsonParser = new JSONParser();
    private static final String LOGIN_URL = "http://192.168.10.38/CI/index.php/login1/addswitchboard";
    //JSON element ids from repsonse of php script:
    // private ProgressDialog pDialog;
    //StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
//    private ArrayList <String> listItems = new ArrayList <String>();
    private  List<String> phrasesCollection = new LinkedList<String>();
    SharedPreferences prefs;
    public static final String TAG_SUCCESS = "success";
    public static final String TAG_MESSAGE = "message";
    private static final String TAG_INFO = "info";
    JSONObject json;
    Button show;
    EditText et,input;
    public static final String MY_PREFS_NAME = "enerleaf11";
    String msg = "Android : ";
    ArrayAdapter<String> adp;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main11);

        li = new ArrayList<String>();
//        li.add("List 1");
        //      li.add("List 2");
        //    li.add("List 3");

        final Button show = (Button) findViewById(R.id.addswb);

        Button sh = (Button) findViewById(R.id.homeseek);
        list = (ListView) findViewById(R.id.listView1);
        add();
        show.setOnClickListener(this);
        sh.setOnClickListener(this);
        et = (EditText) findViewById(R.id.swb);
     //   SharedPreferences prefs = getSharedPreferences(
     //           "mmaamamama", Context.MODE_PRIVATE);
    /*    String restoredText = prefs.getString("text", null);
        if (restoredText != null) {
            if (et.getText().toString().trim().length() > 0) {

                for(int i = 0;i<prefs.getAll().size();i++) {
                    String name1 = prefs.getString(i+"switchboardid", "");

                    li.add(name1);
                }
                //   li.add(et.getText().toString());
            }
        }*/
     /*   for (int i = 0; ; ++i) {
            final String str = prefs.getString(i+"switchboard", "");
            if (!str.equals("")) {
                adp.add(str);
            } else {
                break; // Empty String means the default value was returned.
            }
        }*/
    }

  /*  @Override
    public void onStart() {
        super.onStart();

        SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
  /*      String restoredText = prefs.getString("text", null);
        if (restoredText != null) {
           for(int i = 0;i<prefs.getAll().size();i++) {
               String name1 = prefs.getString(i+"switchboard", "");//"No name defined" is the default value.
               //  String name2 = prefs.getString("name2", "No");

               li.add(name1);
           }

        }
        for (int i = 0; ; ++i) {
            final String str = prefs.getString(i+"switchboard","");
            if (!str.equals("")) {
                adp.add(str);
                Log.d(msg, "The onStart() event");
            } else {
                break; // Empty String means the default value was returned.
            }
        }
    }*/

    @Override
    protected void onResume() {
        super.onResume();

        SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
       /* String restoredText = prefs.getString("text", null);
        if (restoredText != null) {
            for(int i = 0; i < prefs.getAll().size();i++){
            String name1 = prefs.getString(i+"switchboard", "");//"No name defined" is the default value.
            //  String name2 = prefs.getString("name2", "No");

            li.add(name1);}

        }*/
        for (int i = 0;; ++i) {
            final String str = prefs.getString(i+"switchboard", "");
            if (!str.equals("")) {
                adp.add(str);
                Log.d(msg, "The onResume() event");
            } else {
                break; // Empty String means the default value was returned.
            }
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
        if (et.getText().toString().trim().length() > 0) {
            SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
            //
           /*     String dim1 = et.getText().toString();
                Log.d("onpause", dim1);

            for(int i = 0;i<li.size();i++) {
                editor.putString("text", "h");
                editor.putString(i+"switchboard", dim1);
                //  editor.putString("name2", dim2);

           }
            editor.commit();*/

            editor.clear();
            for (int i = 0; i < adp.getCount(); ++i){
                // This assumes you only have the list items in the SharedPreferences.
                editor.putString(i+"switchboard", adp.getItem(i));
                Log.d(msg, "The onPause() event");
            }
            editor.commit();

        }
    }
   @Override
    public void onStop() {
       super.onStop();

        SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
        if (et.getText().toString().trim().length() > 0) {

         /*     String dim1 = et.getText().toString();
              Log.d("onstop", dim1);
              //  String dim2 = (String) activity_Home_Tv_Temperature.getText();
            for(int i=0;i<li.size();i++) {
              editor.putString("text", "h");
              editor.putString(i+"switchboard", dim1);
              //   editor.putString("name2", dim2);

        }
            editor.commit();*/

            editor.clear();
            for (int i = 0; i<adp.getCount(); ++i){
                // This assumes you only have the list items in the SharedPreferences.
                editor.putString(i+"switchboard", adp.getItem(i));
                Log.d(msg, "The onStop() event");
            }
            editor.commit();

        }
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (et.getText().toString().trim().length() > 0) {
            SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
//

          /*      String dim1 = et.getText().toString();
                Log.d("ondestroy", dim1);
            for(int i=0;i<li.size();i++) {
                editor.putString("text", "h");
                editor.putString(i+"switchboard", dim1);


            }
            editor.commit();

        }*/
            editor.clear();
            for (int i = 0; i < adp.getCount(); ++i) {
                // This assumes you only have the list items in the SharedPreferences.
                editor.putString(i+"switchboard", adp.getItem(i));
                Log.d(msg, "The onDestroy() event");
            }
            editor.commit();


        }

    }
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.addswb: {


                if (et.getText().toString().trim().length() <= 0) {
                    Toast.makeText(getApplicationContext(), "Error!", Toast.LENGTH_LONG).show();
                } else {
                    //Context context;
                  /*  AlertDialog.Builder alert = new AlertDialog.Builder(AddSwitchBoard.this);
                    alert.setTitle("Alert Dialog With EditText"); //Set Alert dialog title here
                    alert.setMessage("Enter Your Name Here"); //Message here

                    // Set an EditText view to get user input
                    input = new EditText(AddSwitchBoard.this);
                    alert.setView(input);

                    alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            new Addsw().execute();
                        }
                    }); //End of alert.setPositiveButton
                    alert.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            // Canceled.
                            dialog.cancel();
                        }
                    }); //End of alert.setNegativeButton
                    AlertDialog alertDialog = alert.create();
                    alertDialog.show();
*/

                new Addsw().execute();
               }

                break;
            }
            case R.id.homeseek: {
                Intent intent = new Intent(com.example.hcl.myapplication.AddSwitchBoard.this, Home.class);
                startActivity(intent);
                finish();
                break;
            }
        }
    }





    public void add()
    {
         adp=new ArrayAdapter<String>
                (getBaseContext(),R.layout.list, label,li);
        list.setAdapter(adp);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,int arg2,
                                    long arg3) {
                String aa = li.get(arg2);
                Toast.makeText(getBaseContext(), li.get(arg2),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }



    class Addsw extends AsyncTask<String, String, String> {


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected String doInBackground(String... args) {
            // TODO Auto-generated method stub
            SharedPreferences prefs = getSharedPreferences("enerleaf0", MODE_PRIVATE);

            String name1 = prefs.getString("userid", "");//"No name defined" is the default value.
            Log.d("name",name1);

            Log.d("my app", "do in back");
            String Show = et.getText().toString();

            Log.d("my app", "do in back after init");
           // String password = pass.getText().toString();

            Log.d("my app", "inside try");
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("Show", Show));
           params.add(new BasicNameValuePair("userID", name1));
            Log.d("request!", "in baCK" + params.toString());
            Log.d("request!", "starting");


            json = jsonParser.makeHttpRequest(LOGIN_URL, "POST", params);
            // String s = null;
            Log.d("my app", "   hhhh    " + json.toString());


            try {
                int success = json.getInt(TAG_SUCCESS);
                //String message = json.getString(TAG_MESSAGE);
                // s = json.getString(TAG_SUCCESS);
                //  Log.d("Msg", json.getString(TAG_INFO));
                if (success == 1) {
                    AddSwitchBoard.this.runOnUiThread(new Runnable() {


                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "successfully entered!", Toast.LENGTH_LONG).show();
                            Log.d("myapp","running");


                            li.add(et.getText().toString());
                          //  et.setText(null);
                            add();


                        }


                    });



                } else if (success == 0) {

                    AddSwitchBoard.this.runOnUiThread(new Runnable() {


                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "wrong thing entered", Toast.LENGTH_LONG).show();
                        }
                    });

                    Log.d("Login Failure!", json.getString(TAG_SUCCESS));
//
                    return json.getString(TAG_SUCCESS);


                }
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                //  Toast.makeText(MainActivity.this, "wrong thing entered", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }

            return null;

        }




    }

        @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main11, menu);
        return true;
    }
}