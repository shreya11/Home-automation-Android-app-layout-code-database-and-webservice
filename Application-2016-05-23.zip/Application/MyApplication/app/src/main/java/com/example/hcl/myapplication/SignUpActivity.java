package com.example.hcl.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONObject;


public class SignUpActivity extends Activity  {

        EditText name, emailID, password, confirm_password,mobile;
    // JSON parser class

    JSONParser jsonParser = new JSONParser();
    private static final String LOGUP_URL = "http://192.168.10.38/CI/index.php/login1/sign_up";
    JSONObject json;
    public static final String TAG_SUCCESS = "success";
  //  public static final String TAG_MESSAGE = "message";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        name = (EditText) findViewById(R.id.RegName);
       // Bundle name = new Bundle();
        emailID = (EditText) findViewById(R.id.Email);
        password = (EditText) findViewById(R.id.passcode);
        confirm_password = (EditText) findViewById(R.id.confirmpasscode);
        mobile = (EditText) findViewById(R.id.phone);
        Button signup = (Button) findViewById(R.id.signupbutton);

        signup.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
              //  new signUpActivity().execute();
               // Intent myIntent1 = new Intent( view.getContext(), com.example.hcl.myapplication.MessageActivity.class);
               // startActivityForResult(myIntent1, 0);
                Intent logup = new Intent(getApplicationContext(), MessageActivity.class);
                logup.putExtra("name",name.getText().toString());
                logup.putExtra("emailID",emailID.getText().toString());
                logup.putExtra("password",password.getText().toString());
                logup.putExtra("confirm_password",confirm_password.getText().toString());
                logup.putExtra("mobile",mobile.getText().toString());
                startActivity(logup);
                finish();
            }
        });

    }
/*
    class signUpActivity extends AsyncTask<String, String, String> {


    @Override
    protected void onPreExecute() {
        super.onPreExecute();

    }
    @Override
    protected String doInBackground(String... args) {
        // TODO Auto-generated method stub

        WifiManager manager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = manager.getConnectionInfo();
        String address = info.getMacAddress();
        Log.d("my app", "do in back");
        String RegName = name.getText().toString();
        Log.d("my app", "do in back after init");
        String emailId = emailID.getText().toString();
        String passcode = password.getText().toString();
        String confirmPasscode = confirm_password.getText().toString();
        String phone_num = mobile.getText().toString();

        Log.d("my app", "inside try");
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("RegName", RegName));
        params.add(new BasicNameValuePair("emailID", emailId));
        params.add(new BasicNameValuePair("password", passcode));
        params.add(new BasicNameValuePair("confirm_Password", confirmPasscode));
        params.add(new BasicNameValuePair("phone_Num", phone_num));
        Log.d("my app", "after phn");
        params.add(new BasicNameValuePair("APP_MAC",address));
        Log.d("request!", "in baCK" + params.toString());
        Log.d("request!", "starting");



        json = jsonParser.makeHttpRequest(LOGUP_URL, "POST", params);
        // String s = null;
        Log.d("my app","   hhhh    "+json.toString());


        try {
           // JSONObject jsonObject = json.getJSONObject("success");
            int success = json.getInt(TAG_SUCCESS);
            //String message = json.getString(TAG_MESSAGE);
            // s = json.getString(TAG_SUCCESS);
            //  Log.d("Msg", json.getString(TAG_INFO));
            if (success == 1) {
             //   Intent logup = new Intent(getApplicationContext(), MessageActivity.class);
                SignUpActivity.this.runOnUiThread(new Runnable(){


                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(), "Registration successful", Toast.LENGTH_LONG).show();
                    }
                });
             //   logup.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
             //   startActivity(logup);
            //   finish();
            }
            else if(success == 0){

                SignUpActivity.this.runOnUiThread(new Runnable(){


                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(), "wrong thing entered", Toast.LENGTH_LONG).show();
                    }
                });

                Log.d("Login Failure!", json.getString(TAG_SUCCESS));
//
                return json.getString(TAG_SUCCESS);




            }
        } catch (JSONException e) {
            // TODO Auto-generated catch block
          //  Toast.makeText(MainActivity.this, "wrong thing entered", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }

        return null;

    }


}

*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_sign_up, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
