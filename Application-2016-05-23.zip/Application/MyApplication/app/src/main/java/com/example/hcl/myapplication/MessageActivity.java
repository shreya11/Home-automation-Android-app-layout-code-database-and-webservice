package com.example.hcl.myapplication;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MessageActivity extends Activity implements View.OnClickListener {
        EditText enterkey;
    EditText input;
    int i;
    String PINString;
    int randomPIN;
    EditText name, emailID, password, confirm_password,mobile;
    // JSON parser class

    JSONParser jsonParser = new JSONParser();
    private static final String LOGUP_URL = "http://192.168.10.38/CI/index.php/login1/sign_up";
    JSONObject json;
    public static final String TAG_SUCCESS = "success";
    //  public static final String TAG_MESSAGE = "message";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        enterkey = (EditText) findViewById(R.id.EnterKey);
       // String enterKeyText = enterkey.getText().toString();

        Button okbutton = (Button) findViewById(R.id.OkButton);
        okbutton.setOnClickListener(this);
    }
    protected void sendSMSMessage() {
        Log.i("Send SMS", "");
        String phoneNo = enterkey.getText().toString();
        //generate a 4 digit integer 1000 <10000
        randomPIN = (int)(Math.random()*9000)+1000;

        //Store integer in a string
        PINString = String.valueOf(randomPIN);

        //  String message = txtMessage.getText().toString();

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNo, null, "your pincode is: " + randomPIN, null, null);
            Toast.makeText(getApplicationContext(), "SMS sent.", Toast.LENGTH_LONG).show();
            alert();

        }

        catch (Exception e) {
            Toast.makeText(getApplicationContext(), "SMS faild, please try again.", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private void alert() {
        final AlertDialog.Builder alert = new AlertDialog.Builder(MessageActivity.this);
        alert.setTitle("message"); //Set Alert dialog title here
        alert.setMessage("you'll get your pin in some time and if you don't get then click here"); //Message here

         // Set an EditText view to get user input
      /*  input = new TextView(MessageActivity.this);
        alert.setView(input);
*/
        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                alert1();
            }
        }); //End of alert.setPositiveButton
        alert.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // Canceled.
                dialog.cancel();
            }
        }); //End of alert.setNegativeButton
        AlertDialog alertDialog = alert.create();
        alertDialog.show();
    }

    private void alert1() {
        final AlertDialog.Builder alert = new AlertDialog.Builder(MessageActivity.this);
        alert.setTitle("PIN"); //Set Alert dialog title here
        alert.setMessage("Enter your pincode here!!"); //Message here

        // Set an EditText view to get user input
        input = new EditText(MessageActivity.this);
        alert.setView(input);

        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                Log.d("myapp",PINString);
                Log.d("myapp",input.getEditableText().toString());

                if((input.getText().toString().compareToIgnoreCase(String.valueOf(randomPIN)) == 0))
                {
                   // Toast.makeText(MessageActivity.this,"registered successfully!",Toast.LENGTH_LONG).show();
                    new signUpActivity().execute();
                }
                else
                {
                    Toast.makeText(MessageActivity.this,"wrong pin",Toast.LENGTH_LONG).show();
                }
            }
        }); //End of alert.setPositiveButton
        alert.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                // Canceled.
                dialog.cancel();
            }
        }); //End of alert.setNegativeButton
        AlertDialog alertDialog = alert.create();
        alertDialog.show();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_message, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        sendSMSMessage();
    }
    class signUpActivity extends AsyncTask<String, String, String> {


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }
        @Override
        protected String doInBackground(String... args) {
            // TODO Auto-generated method stub

            WifiManager manager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = manager.getConnectionInfo();
            String address = info.getMacAddress();
            Intent intent = getIntent();
          //  String easyPuzzle = intent.getExtras().getString("epuzzle");
            Log.d("my app", "do in back");
            String RegName = intent.getExtras().getString("name");//name.getText().toString();
            Log.d("my app", "do in back after init");
            String emailId = intent.getExtras().getString("emailID");//emailID.getText().toString();
            String passcode = intent.getExtras().getString("password");//password.getText().toString();
            String confirmPasscode = intent.getExtras().getString("confirm_password");//confirm_password.getText().toString();
            String phone_num = intent.getExtras().getString("mobile");//mobile.getText().toString();

            Log.d("my app", "inside try");
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("RegName", RegName));
            params.add(new BasicNameValuePair("emailID", emailId));
            params.add(new BasicNameValuePair("password", passcode));
            params.add(new BasicNameValuePair("confirm_Password", confirmPasscode));
            params.add(new BasicNameValuePair("phone_Num", phone_num));
            Log.d("my app", "after phn");
            params.add(new BasicNameValuePair("APP_MAC",address));
            Log.d("request!", "in baCK" + params.toString());
            Log.d("request!", "starting");



            json = jsonParser.makeHttpRequest(LOGUP_URL, "POST", params);
            // String s = null;
            Log.d("my app","   hhhh    "+json.toString());


            try {
                // JSONObject jsonObject = json.getJSONObject("success");
                int success = json.getInt(TAG_SUCCESS);
                //String message = json.getString(TAG_MESSAGE);
                // s = json.getString(TAG_SUCCESS);
                //  Log.d("Msg", json.getString(TAG_INFO));
                if (success == 1) {
                    //   Intent logup = new Intent(getApplicationContext(), MessageActivity.class);
                    MessageActivity.this.runOnUiThread(new Runnable(){


                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Registration successful", Toast.LENGTH_LONG).show();
                        }
                    });
                    //   logup.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    //   startActivity(logup);
                    //   finish();
                }
                else if(success == 0){

                    MessageActivity.this.runOnUiThread(new Runnable(){


                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "wrong thing entered", Toast.LENGTH_LONG).show();
                        }
                    });

                    Log.d("Login Failure!", json.getString(TAG_SUCCESS));
//
                    return json.getString(TAG_SUCCESS);




                }
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                //  Toast.makeText(MainActivity.this, "wrong thing entered", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }

            return null;

        }


    }

}
